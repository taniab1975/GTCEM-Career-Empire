Avatar Studio Starter Pieces

Use these files to create student-made avatar parts for the Career Empire Avatar Studio.

Live studio: https://taniab1975.github.io/GTCEM-Career-Empire/modules/avatar/index.html

Current live target:
- Canvas: 1280 x 720 px
- Format: transparent PNG
- Export new parts on the full canvas, already positioned on the avatar
- Do not crop tightly around the item
- Remove labels, backgrounds, shadows, borders, and neighbouring items

Included folders:
- current-live-take-2/: current approved live layers for alignment and colour reference
- templates/: blank transparent canvas, dark background test, preview composite, and asset notes template

Submission pack structure:
avatar-submission/
  final-png-layers/
  preview-composites/
  source-files/
  asset-notes.txt
